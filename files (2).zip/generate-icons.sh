#!/bin/bash

# This script generates PWA icons from a source image
# You'll need ImageMagick installed: apt-get install imagemagick

# Usage: ./generate-icons.sh your-icon-source.png

if [ -z "$1" ]; then
    echo "📱 PWA Icon Generator"
    echo ""
    echo "This will create placeholder icons for now."
    echo "To use your own icon, run: ./generate-icons.sh your-icon.png"
    echo ""
    
    # Create simple placeholder icons using ImageMagick
    # These create a gradient purple square with text
    
    convert -size 192x192 \
        -background 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' \
        -fill white \
        -pointsize 72 \
        -gravity center \
        label:"WL" \
        icon-192.png 2>/dev/null || {
            echo "ImageMagick not installed. Creating basic icons..."
            echo "Install ImageMagick or manually create icon-192.png and icon-512.png"
        }
    
    convert -size 512x512 \
        -background 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' \
        -fill white \
        -pointsize 200 \
        -gravity center \
        label:"WL" \
        icon-512.png 2>/dev/null
else
    SOURCE=$1
    
    if [ ! -f "$SOURCE" ]; then
        echo "Error: File $SOURCE not found"
        exit 1
    fi
    
    echo "Generating icons from $SOURCE..."
    
    # Generate 192x192
    convert "$SOURCE" -resize 192x192 icon-192.png
    
    # Generate 512x512
    convert "$SOURCE" -resize 512x512 icon-512.png
    
    echo "✅ Icons generated successfully!"
fi

echo ""
echo "Created icons:"
echo "  - icon-192.png (192x192)"
echo "  - icon-512.png (512x512)"
