# 🚀 QUICK START - Deploy in 10 Minutes

## Step 1: Supabase Setup (3 minutes)

1. Go to https://supabase.com
2. Click "Start your project" → Sign in with GitHub
3. Click "New Project"
   - Name: `weight-loss`
   - Password: (create one)
   - Region: Choose closest
4. Click "Create new project" → Wait 2 minutes
5. When ready, click "SQL Editor" (left sidebar)
6. Copy ALL text from `supabase-schema.sql`
7. Paste into SQL editor → Click "RUN"
8. Click "Storage" (left sidebar) → "New bucket"
   - Name: `weight-loss-photos`
   - Check "Public bucket" ✓
   - Click "Create"
9. Click ⚙️ Settings → API
   - Copy "Project URL"
   - Copy "anon public" key

## Step 2: Configure App (1 minute)

1. Open `supabase-config.js`
2. Paste your Project URL (line 6)
3. Paste your anon key (line 9)
4. Save file

## Step 3: Deploy to Vercel (3 minutes)

### Option A: Via GitHub (Recommended)
1. Create new repo on GitHub: https://github.com/new
   - Name: `weight-loss-pwa`
   - Public or Private (your choice)
   - Don't initialize
2. In your terminal:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/weight-loss-pwa.git
   git push -u origin main
   ```
3. Go to https://vercel.com
4. Click "Add New" → "Project"
5. Import your GitHub repo
6. Click "Deploy"
7. Done! Get your URL

### Option B: Drag & Drop (Easiest)
1. Go to https://vercel.com
2. Sign in with GitHub
3. Drag the entire `weight-loss-pwa` folder onto the Vercel page
4. Click "Deploy"
5. Done! Get your URL

## Step 4: Install PWA (2 minutes)

**iPhone:**
1. Open Safari → Go to your Vercel URL
2. Tap Share button (square with arrow)
3. Tap "Add to Home Screen"
4. Tap "Add"

**Android:**
1. Open Chrome → Go to your Vercel URL
2. Tap ⋮ menu
3. Tap "Add to Home Screen"

**Desktop:**
1. Open Chrome/Edge → Go to your URL
2. Click install icon in address bar
3. Click "Install"

## Step 5: Start Tracking! 🎯

✅ You're done! Open the app and start your journey!

---

## 💡 Tips

- **Bookmark**: https://YOUR-APP.vercel.app
- **Share**: Send link to Amanda
- **Update**: Just push to GitHub, Vercel auto-deploys
- **Icons**: Replace icon-192.svg and icon-512.svg with your own

## 🆘 Problems?

**Can't see app after deploy?**
- Wait 1 minute, refresh
- Check Vercel deployment logs

**Data not saving?**
- Check browser console (F12)
- Verify Supabase keys in config

**PWA won't install?**
- Must use HTTPS (Vercel provides this)
- Try different browser
- Clear cache

**Need help?**
- Check full README.md
- Vercel docs: vercel.com/docs
- Supabase docs: supabase.com/docs
