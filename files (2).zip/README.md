# Weight Loss Journey PWA - Deployment Guide

Complete guide to deploy your weight loss tracking app as a Progressive Web App (PWA) with Vercel and Supabase.

## 📋 Prerequisites

- GitHub account
- Vercel account (free tier: https://vercel.com)
- Supabase account (free tier: https://supabase.com)

## 🚀 Step-by-Step Deployment

### Part 1: Set Up Supabase (Database)

1. **Create Supabase Project**
   - Go to https://app.supabase.com
   - Click "New Project"
   - Fill in:
     - Name: `weight-loss-journey`
     - Database Password: (create a strong password)
     - Region: Choose closest to you
   - Click "Create new project" (takes ~2 minutes)

2. **Run Database Schema**
   - In your Supabase project, click "SQL Editor" (left sidebar)
   - Click "New Query"
   - Copy the entire contents of `supabase-schema.sql`
   - Paste into the SQL editor
   - Click "RUN" button
   - You should see "Success. No rows returned"

3. **Create Storage Bucket for Photos**
   - Click "Storage" in left sidebar
   - Click "New bucket"
   - Name: `weight-loss-photos`
   - Public bucket: YES (check the box)
   - Click "Create bucket"

4. **Get Your API Credentials**
   - Click "Project Settings" (gear icon in left sidebar)
   - Click "API" in the settings menu
   - Copy these two values (you'll need them later):
     - **Project URL** (e.g., https://xxxxx.supabase.co)
     - **anon/public key** (long string starting with "eyJ...")

5. **Enable Authentication (Optional but recommended)**
   - Click "Authentication" in left sidebar
   - Click "Providers"
   - Enable "Email" provider
   - For now, you can use "Email" sign-in

### Part 2: Configure Your App

1. **Update Supabase Config**
   - Open `supabase-config.js`
   - Replace `YOUR_SUPABASE_URL_HERE` with your Project URL
   - Replace `YOUR_SUPABASE_ANON_KEY_HERE` with your anon key
   - Save the file

2. **Add Your Beach Photo**
   - You have a beach photo you want to use
   - We'll need to convert it to base64
   - Or upload to Supabase Storage and reference the URL

### Part 3: Deploy to Vercel

#### Option A: Deploy via GitHub (Recommended)

1. **Push to GitHub**
   ```bash
   # Initialize git repository
   git init
   
   # Add all files
   git add .
   
   # Commit
   git commit -m "Initial commit - Weight Loss PWA"
   
   # Create a new repository on GitHub (https://github.com/new)
   # Name it: weight-loss-journey-pwa
   # Don't initialize with README
   
   # Add remote (replace YOUR_USERNAME)
   git remote add origin https://github.com/YOUR_USERNAME/weight-loss-journey-pwa.git
   
   # Push to GitHub
   git branch -M main
   git push -u origin main
   ```

2. **Deploy on Vercel**
   - Go to https://vercel.com
   - Click "Add New" → "Project"
   - Click "Import Git Repository"
   - Select your `weight-loss-journey-pwa` repository
   - Click "Import"
   - Configure:
     - Framework Preset: Other
     - Root Directory: ./
     - Build Command: (leave empty)
     - Output Directory: (leave empty)
   - Click "Deploy"
   - Wait ~1 minute for deployment
   - You'll get a URL like: `https://weight-loss-journey-pwa.vercel.app`

#### Option B: Deploy via Vercel CLI (Alternative)

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Deploy**
   ```bash
   cd weight-loss-pwa
   vercel
   ```
   - Follow the prompts
   - Select your Vercel account
   - Link to existing project or create new one
   - Wait for deployment

### Part 4: Install as PWA

#### On iPhone/iPad:
1. Open Safari browser
2. Go to your Vercel URL
3. Tap the "Share" button (square with arrow)
4. Scroll down and tap "Add to Home Screen"
5. Tap "Add"
6. The app icon will appear on your home screen

#### On Android:
1. Open Chrome browser
2. Go to your Vercel URL
3. Tap the three dots menu (⋮)
4. Tap "Add to Home Screen" or "Install App"
5. Tap "Install"
6. The app icon will appear on your home screen

#### On Desktop (Chrome/Edge):
1. Open your Vercel URL
2. Look for the install icon in the address bar (⊕ or computer icon)
3. Click "Install"
4. The app opens in its own window

### Part 5: Set Up User Accounts (Supabase Auth)

1. **Create User Accounts**
   - Go to Supabase Dashboard
   - Click "Authentication" → "Users"
   - Click "Add user"
   - Add emails for David and Amanda
   - Set passwords
   - Click "Create user"

2. **Update App with Auth** (optional enhancement)
   - Currently the app uses local storage
   - Can add login screen to sync across devices

## 🎨 Customization

### Change App Icons

1. Create icon images:
   - **icon-192.png** (192x192 pixels)
   - **icon-512.png** (512x512 pixels)
   
2. Use a tool like:
   - https://realfavicongenerator.net/
   - Or Photoshop/Figma to create square icons

3. Place in the root directory

### Change Beach Photo

Replace the BEACH_IMAGE variable in index.html:

```javascript
// Option 1: Use base64 (current method)
const BEACH_IMAGE = "data:image/jpeg;base64,YOUR_BASE64_STRING";

// Option 2: Use uploaded URL
const BEACH_IMAGE = "https://your-url.com/beach.jpg";
```

## 📱 Features

✅ **Offline Support** - Works without internet
✅ **Install on Phone** - Looks like a native app
✅ **Daily Tracking** - Weight, calories, protein, water, exercise
✅ **Progress Charts** - Visual tracking
✅ **Photo Progress** - Before/after comparison
✅ **Workout Scheduler** - 19-week program
✅ **Meal Logging** - Track your nutrition
✅ **Cloud Sync** - Data synced via Supabase (when online)

## 🔧 Troubleshooting

### App not installing as PWA?
- Make sure you're accessing via HTTPS (Vercel provides this)
- Clear browser cache and try again
- Check manifest.json is accessible at /manifest.json

### Data not syncing?
- Check Supabase credentials in supabase-config.js
- Open browser console (F12) for error messages
- Verify database schema was created correctly

### Photos not uploading?
- Check storage bucket permissions
- Ensure bucket name matches in config
- Verify bucket is set to "public"

## 🆘 Need Help?

1. **Vercel Documentation**: https://vercel.com/docs
2. **Supabase Documentation**: https://supabase.com/docs
3. **PWA Checklist**: https://web.dev/pwa-checklist/

## 📊 Database Backup

To backup your data:
1. Go to Supabase Dashboard
2. Click "Database" → "Backups"
3. Download SQL dump

## 🔐 Security Notes

- Never commit `supabase-config.js` with real credentials to public repos
- Use environment variables for production
- Enable Row Level Security (RLS) policies (already done in schema)
- Regularly update Supabase password

## 🎯 Next Steps

1. ✅ Deploy to Vercel
2. ✅ Set up Supabase
3. ✅ Install PWA on phones
4. 📱 Start tracking!
5. 🏋️ Reach your goals!

---

**Created by David**  
**For David & Amanda's May 2026 Beach Holiday** 🌴

Good luck on your journey! 💪
