# ✅ DEPLOYMENT CHECKLIST

Print this out or keep it open while deploying!

## Pre-Deployment
- [ ] Have GitHub account ready
- [ ] Have Vercel account ready (sign up at vercel.com)
- [ ] Have Supabase account ready (sign up at supabase.com)
- [ ] Your beach photo ready (for later customization)

## Supabase Setup
- [ ] Create new Supabase project
- [ ] Name it "weight-loss" or similar
- [ ] Wait for project to be ready (~2 minutes)
- [ ] Open SQL Editor
- [ ] Paste contents of `supabase-schema.sql`
- [ ] Click RUN button
- [ ] See "Success" message
- [ ] Create storage bucket:
  - [ ] Go to Storage
  - [ ] Create new bucket
  - [ ] Name: `weight-loss-photos`
  - [ ] Make it Public ✓
- [ ] Get API credentials:
  - [ ] Copy Project URL
  - [ ] Copy anon/public key
- [ ] Paste both into `supabase-config.js`

## Vercel Deployment

### Method 1: GitHub (Recommended)
- [ ] Create new GitHub repository
- [ ] Name: `weight-loss-pwa`
- [ ] Don't initialize with README
- [ ] Copy the git commands shown
- [ ] Run commands in terminal
- [ ] Push code to GitHub
- [ ] Go to vercel.com
- [ ] Import GitHub repository
- [ ] Click Deploy
- [ ] Copy your Vercel URL

### Method 2: Drag & Drop
- [ ] Go to vercel.com
- [ ] Drag entire folder onto page
- [ ] Click Deploy
- [ ] Copy your Vercel URL

## Testing
- [ ] Open Vercel URL in browser
- [ ] App loads successfully
- [ ] Switch between David/Amanda
- [ ] Check all tabs work
- [ ] Add a daily check-in
- [ ] Verify data saves

## Install PWA
- [ ] iPhone: Safari → Share → Add to Home Screen
- [ ] Android: Chrome → Menu → Add to Home Screen
- [ ] Desktop: Click install icon in address bar
- [ ] App icon appears on home screen/desktop
- [ ] Open installed app
- [ ] Works offline (try airplane mode)

## Customization (Optional)
- [ ] Add your real beach photo
- [ ] Create custom app icons
- [ ] Update app name if desired
- [ ] Customize colors/theme

## Share with Amanda
- [ ] Send Vercel URL
- [ ] She installs on her phone
- [ ] She creates her profile
- [ ] Both can track independently

## Post-Deployment
- [ ] Bookmark Vercel URL
- [ ] Save Supabase password somewhere safe
- [ ] Set up regular data backups (Supabase → Database → Backups)
- [ ] Start your journey! 🎯

---

## Quick Reference

**Vercel Dashboard:** https://vercel.com/dashboard
**Supabase Dashboard:** https://app.supabase.com
**Your App URL:** ___________________ (write it here)

## Need to Update App?
1. Make changes to files
2. Run: `git add .`
3. Run: `git commit -m "Updated feature"`
4. Run: `git push`
5. Vercel auto-deploys in ~30 seconds

## Troubleshooting
✅ = Working | ❌ = Not working | ⚠️ = Needs attention

- [ ] ✅ App loads
- [ ] ✅ Data saves locally
- [ ] ✅ PWA installs
- [ ] ✅ Works offline
- [ ] ✅ Supabase connected
- [ ] ✅ Photos upload

If any ❌, check:
1. Browser console (F12) for errors
2. Vercel deployment logs
3. Supabase API keys are correct
4. README.md troubleshooting section
